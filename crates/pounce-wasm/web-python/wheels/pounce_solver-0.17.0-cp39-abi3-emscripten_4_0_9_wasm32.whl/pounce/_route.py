"""Structure detection + extraction to auto-route a scipy-style
:func:`pounce.minimize` problem to the specialized convex solvers — the LP/QP
interior-point solver (:func:`classify_and_extract`) or, for a convex QCQP, the
conic SOCP solver (:func:`classify_and_extract_socp`).

The CLI classifies a problem by walking its symbolic ``.nl`` expression tree,
so its routing is *certain*. ``minimize`` takes opaque Python callables
(``fun``/``jac``/``hess`` and constraint functions), so we cannot read the
structure — we have to **probe** the callables at several points, fit a
linear/quadratic model, and then **validate** that model against the true
functions at held-out points before trusting it. For a QCQP we additionally
probe each constraint's Hessian to recover its quadratic form.

Detection is deliberately conservative. The two misclassification directions
are not symmetric:

* a convex LP/QP/QCQP routed to the NLP solver is merely *slower* — the
  filter-IPM solves it correctly;
* a genuinely nonlinear or nonconvex problem routed to a convex solver returns
  a **silently wrong** answer.

So the held-out validation gates the dangerous direction: any probe that
raises, any model mismatch beyond tolerance, a non-constant Hessian/Jacobian,
an indefinite objective Hessian (nonconvex QP), a quadratic equality, or a
quadratic inequality whose feasible set is nonconvex (a non-PSD constraint
Hessian) all fall back to ``None`` — meaning "let the general NLP solver handle
it."
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass

import numpy as np

_EPS = float(np.finfo(np.float64).eps)
# Central-difference steps: ~eps^(1/2) for a first derivative (gradient) and
# ~eps^(1/3) for a second derivative (Hessian), the usual optimal balances of
# truncation vs. round-off error.
_H_GRAD = _EPS**0.5
_H_HESS = _EPS ** (1.0 / 3.0)
# Step for every derivative read off ``fun`` alone — the gradient when there is
# no ``jac``, and the Hessian of that gradient (gh #1169). The optimal-balance
# steps above minimize truncation + round-off for a *general* function, but the
# router only has to be accurate on the functions it accepts: a central
# difference of a linear or quadratic function has **no** truncation error at
# any step, so only round-off (``~eps·|f|/h``, then ``/h`` again for the nested
# Hessian) is left, and it shrinks as the step grows. At ``sqrt(eps)`` and
# ``eps^(1/3)`` the nested Hessian carried ``~2.5e-3·|f|`` of noise, so a QP
# whose objective merely had a constant offset of 1 failed the Hessian-constancy
# gate. At 2^-2 the gradient carries ``~1e-15·|f|`` and the nested Hessian
# ``~4e-15·|f|``. Anything not quadratic is still caught by the gates: its
# Hessian still varies between probes, and its fitted model still misses
# ``fun`` at the held-out points. The step is the probe region's own scale
# (``_probe_points`` spreads probes by ``max(1, |x0|)``, or a quarter of the
# box), so the stencils do not look further than the probes already do, and
# ``_box_diff`` keeps them in the box. A power of two keeps ``x ± h`` exact
# for moderate ``x``.
_H_STRUCT = 2.0**-2
# Rounding of one ``fun`` value, in units of ``eps·|f|``, assumed by the LP
# gate's round-off allowance (:func:`_objective_model`). A ``fun`` that rounds
# worse than this is under-allowed, so it can only fail the LP gate and be
# fitted as a QP, the pre-gh #1169 behaviour. It can never pass the gate for
# that reason.
_F_ULPS = 8.0


@dataclass
class QpExtract:
    """An LP/QP recovered from the callable problem.

    ``kind`` is ``"lp"`` (``P is None``), ``"convex_qp"``, or —
    only when the caller passed ``allow_indefinite=`` and so holds an engine
    for it — ``"nonconvex_qp"`` (gh #786). The objective is
    ``½ xᵀP x + cᵀx + obj_const``; ``obj_const`` is the degree-0 term that the
    QP solver does not see and must be added back to the reported value.
    Equality block is ``A x = b``, inequality block ``G x ≤ h``, with box
    ``lb ≤ x ≤ ub`` (either may be ``None``).
    """

    kind: str
    P: np.ndarray | None
    c: np.ndarray
    obj_const: float
    A: np.ndarray | None
    b: np.ndarray | None
    G: np.ndarray | None
    h: np.ndarray | None
    lb: np.ndarray | None
    ub: np.ndarray | None


def _rotated_cone_balance(b):
    """The rotated cone's balancing factor for constant ``b`` (gh #1056): the
    power of two nearest ``√|b|``, or ``1`` when ``|b| ≤ 1``. Mirrors
    ``rotated_cone_balance`` in the CLI's ``qp_extract.rs``; see there."""
    b = abs(float(b))
    if not (b > 1.0) or not np.isfinite(b):
        return 1.0
    # floor(x + ½), not round(): Rust's `round` is half-away-from-zero.
    k = 2.0 ** int(np.floor(0.5 * np.log2(b) + 0.5))
    return k if np.isfinite(k) and k > 0.0 else 1.0


@dataclass
class SocpExtract:
    """A convex QCQP recovered from the callable problem, reformulated to a
    standard-form second-order cone program for :func:`pounce.solve_socp`.

    ``kind`` is always ``"convex_qcqp"``. The objective is the same
    ``½ xᵀP x + cᵀx + obj_const`` as :class:`QpExtract` (``P`` may be ``None``
    for a linear objective). Equalities are ``A x = b``. The inequality block
    ``G x`` is partitioned by ``cones`` (a list of ``(kind, dim)`` tuples for
    ``solve_socp``): a leading ``("nonneg", k)`` orthant block carrying the
    linear inequalities and finite variable bounds (``s = h − Gx ≥ 0``), then
    one ``("soc", r+2)`` block per convex-quadratic constraint. There is no
    separate box — bounds are folded into the nonnegative block, exactly as the
    CLI's ``extract_socp_with_map`` does.
    """

    kind: str
    P: np.ndarray | None
    c: np.ndarray
    obj_const: float
    A: np.ndarray | None
    b: np.ndarray | None
    G: np.ndarray | None
    h: np.ndarray | None
    cones: list


class _NotConvex(Exception):
    """Internal sentinel: the problem is not a confidently-convex LP/QP."""


_MISS = object()


def _point_cache(f: Callable | None) -> Callable | None:
    """Wrap a callable so repeated evaluations at the *same point* return a
    cached result, keyed on the point's exact float64 bytes.

    The LP/QP router (:func:`classify_and_extract`) and the SOCP router
    (:func:`classify_and_extract_socp`) build an identical probe set (same RNG
    seed) and finite-difference the *same* objective, so the ``auto`` path in
    :func:`pounce.minimize` would otherwise probe the objective twice (~8n²
    redundant ``fun`` evaluations at FD). Sharing one cache across both router
    calls turns the second router's probes into cache hits.

    ``None`` passes through (an absent ``jac``/``hess``). Cached values are
    stored as defensive float64 *copies*, never as the user's return object: a
    ``jac``/``hess`` that reuses one output buffer across calls would otherwise
    mutate earlier cache entries in place and poison the routers' probe data
    (M34). Scalars (a ``fun`` value) become 0-d arrays, which every router
    consumer already accepts (``float(...)`` / ``np.asarray(...)``).
    """
    if f is None:
        return None
    cache: dict = {}

    def wrapped(x):
        key = np.asarray(x, dtype=np.float64).tobytes()
        hit = cache.get(key, _MISS)
        if hit is not _MISS:
            return hit
        val = np.array(f(x), dtype=np.float64, copy=True)
        cache[key] = val
        return val

    return wrapped


def _box_diff(f, x, i, base, floor, lb, ub, *, quadratic, noise=None):
    """Derivative of ``f`` along coordinate ``i`` at ``x``, from a stencil kept
    inside the box ``[lb, ub]`` (gh #1169).

    The step is ``base`` scaled by ``max(1, |x_i|)``. With that much room on
    both sides the stencil is central. Otherwise — a probe clipped onto a
    bound, which is routine — it is one-sided into the larger room, and still
    exact on the class the router accepts: three points (exact on a
    quadratic, ``quadratic=True``, for a gradient of ``fun``) or two (exact on
    an affine function, for the Hessian of a gradient that is affine when the
    objective is quadratic). If even the one-sided step would fall below
    ``floor`` (likewise scaled; the step used before gh #1169), the box is too
    narrow and the stencil is central at ``floor``, as it always was.

    Differences are divided by the step *as represented*, so rounding in
    ``x ± h`` does not enter the quotient. Given a list ``noise``, appends the
    quotient's round-off bound, ``_F_ULPS·eps·Σ|c_k·f_k| / |Δ|``, computed
    from the values the stencil combined."""
    scale = max(1.0, abs(float(x[i])))
    h = base * scale
    lo_room = float(x[i] - lb[i]) if lb is not None and np.isfinite(lb[i]) else np.inf
    hi_room = float(ub[i] - x[i]) if ub is not None and np.isfinite(ub[i]) else np.inf

    def at(t):
        y = x.copy()
        y[i] += t
        return y

    if min(lo_room, hi_room) >= h:
        xp, xm = at(h), at(-h)
        terms, denom = ((1.0, xp), (-1.0, xm)), xp[i] - xm[i]
    else:
        side = 1.0 if hi_room >= lo_room else -1.0
        reach = 2.0 if quadratic else 1.0
        hs = min(h, max(lo_room, hi_room) / reach)
        if hs < floor * scale:
            hf = floor * scale
            xp, xm = at(hf), at(-hf)
            terms, denom = ((1.0, xp), (-1.0, xm)), xp[i] - xm[i]
        else:
            x1 = at(side * hs)
            d1 = x1[i] - x[i]
            if not quadratic:
                terms, denom = ((1.0, x1), (-1.0, x)), d1
            else:
                # Exact for a quadratic on the points 0, d1, 2·d1 (all
                # representable multiples here, since d1 is the represented
                # step).
                terms = ((-3.0, x), (4.0, x1), (-1.0, at(2.0 * d1)))
                denom = 2.0 * d1
    vals = [(c, f(y)) for c, y in terms]
    out = sum(c * v for c, v in vals) / denom
    if noise is not None:
        # Round-off bound of the quotient, from the values it combined.
        noise.append(
            _F_ULPS * _EPS * sum(abs(c) * np.abs(v) for c, v in vals) / abs(denom)
        )
    return out


def _grad_fn(fun: Callable, jac: Callable | None, lb=None, ub=None) -> Callable:
    """Return a gradient callable: the user's ``jac`` if given, else a
    central finite-difference of ``fun`` (central, not forward, because the
    structure tests want the extra accuracy) with the :data:`_H_STRUCT` step,
    kept inside the box ``[lb, ub]`` (see :func:`_box_diff`)."""
    if jac is not None:
        return lambda x: np.asarray(jac(x), dtype=np.float64).ravel()

    def fval(x):
        v = float(fun(x))
        if not np.isfinite(v):
            raise _NotConvex("objective is not finite at a probe")
        return v

    noise_at: dict = {}

    def g(x):
        out = np.empty(x.size)
        nz: list = []
        for i in range(x.size):
            out[i] = _box_diff(
                fval, x, i, _H_STRUCT, _H_GRAD, lb, ub, quadratic=True, noise=nz
            )
        noise_at[np.asarray(x, dtype=np.float64).tobytes()] = np.asarray(nz)
        return out

    def noise(x):
        """Per-component round-off bound of ``g(x)``, which must have run."""
        return noise_at[np.asarray(x, dtype=np.float64).tobytes()]

    # Tag the FD gradient so `_hessian` differences it with a step sized for
    # a round-off-only error, not for an exact gradient's, and so the LP gate
    # can allow for its round-off.
    g.fd_box = (lb, ub)
    g.noise = noise
    return g


def _hessian(grad: Callable, x: np.ndarray, hess: Callable | None) -> np.ndarray:
    """Symmetric Hessian at ``x`` — the user's ``hess`` if given, else a
    central finite-difference of the gradient.

    When the gradient is itself a finite difference of ``fun`` (no ``jac``),
    the stencil is :func:`_box_diff`'s with the :data:`_H_STRUCT` step
    (gh #1169). With an analytic ``jac`` it is exactly as before."""
    if hess is not None:
        return np.asarray(hess(x), dtype=np.float64).reshape(x.size, x.size)
    n = x.size
    H = np.empty((n, n))
    box = getattr(grad, "fd_box", None)
    for j in range(n):
        if box is None:
            step = _H_HESS * max(1.0, abs(x[j]))
            xp = x.copy()
            xm = x.copy()
            xp[j] += step
            xm[j] -= step
            H[:, j] = (grad(xp) - grad(xm)) / (2.0 * step)
        else:
            H[:, j] = _box_diff(
                grad, x, j, _H_STRUCT, _H_HESS, box[0], box[1], quadratic=False
            )
    return 0.5 * (H + H.T)


def _constraint_jac(g_combined, jac_combined, fd_rows, lb, ub):
    """The router's constraint Jacobian ``x ↦ m×n``.

    ``fd_rows`` marks the rows that have no analytic Jacobian, for which
    ``jac_combined`` returns the NLP path's finite difference. That one's
    round-off scales with the row's *value*, so a linear or convex-quadratic
    constraint with a large constant term read as nonlinear (gh #1169, the
    constraint half). Those rows are differenced here from ``g_combined``
    instead, with :func:`_box_diff`'s stencil, exact on quadratics. Rows with
    an analytic Jacobian are read from ``jac_combined`` as before. With no
    ``fd_rows``, or none set, ``jac_combined`` is returned unchanged.

    The returned callable carries ``fd_box``, ``fd_idx`` and ``exact`` (the
    original ``jac_combined``, or ``None`` when every row is differenced),
    which :func:`_all_constraint_hessians` reads to pick its stencil per row.
    """
    if fd_rows is None:
        return jac_combined
    fd_rows = np.asarray(fd_rows, dtype=bool)
    if not fd_rows.any():
        return jac_combined
    idx = np.flatnonzero(fd_rows)
    m = fd_rows.size
    all_fd = idx.size == m

    def g_fd(x):
        v = np.asarray(g_combined(x), dtype=np.float64).ravel()[idx]
        if not np.all(np.isfinite(v)):
            raise _NotConvex("a constraint is not finite at a probe")
        return v

    def J(x):
        n = x.size
        if all_fd:
            out = np.zeros((m, n))
        else:
            out = np.array(
                np.atleast_2d(np.asarray(jac_combined(x), dtype=np.float64)), copy=True
            )
        for i in range(n):
            out[idx, i] = _box_diff(
                g_fd, x, i, _H_STRUCT, _H_GRAD, lb, ub, quadratic=True
            )
        return out

    J.fd_box = (lb, ub)
    J.fd_idx = idx
    J.exact = None if all_fd else jac_combined
    return J


def _probe_points(x0, lb, ub, rng, k=5):
    """``x0`` plus ``k`` random in-domain probe points.

    Steps are scaled to the box width (when finite) or to ``max(1, |x0|)``,
    and clipped back into ``[lb, ub]`` so we never evaluate the user's
    functions outside their declared domain (a log-barrier objective, say).
    The first point is the anchor used to read off coefficients; the rest are
    held out for validation.
    """
    n = x0.size
    if lb is not None and ub is not None:
        width = ub - lb
        finite = np.isfinite(width)
        span = np.where(
            finite, np.maximum(width, 1e-6) * 0.25, np.maximum(np.abs(x0), 1.0)
        )
    else:
        span = np.maximum(np.abs(x0), 1.0)
    pts = [x0.copy()]
    for _ in range(k):
        p = x0 + span * rng.standard_normal(n)
        if lb is not None:
            p = np.maximum(p, lb)
        if ub is not None:
            p = np.minimum(p, ub)
        pts.append(p)
    return pts


# A ``fun`` whose values across the probe region differ by fewer than this
# many units of its own rounding (``eps·|f|``) has, in effect, a constant
# term that hides its shape at double precision. Measured on the gh #1169 QP:
# it stops routing between offsets 3e11 (``1.7e4`` units) and 1e12
# (``5.2e3``). Used only to explain a decline, never to route.
_HIDDEN_ULPS = 1e5


def constant_term_hides_structure(fun, x0, lb, ub, seed: int = 0):
    """``(|f|, spread)`` when ``fun``'s spread over the router's probe points is
    within :data:`_HIDDEN_ULPS` units of its rounding, else ``None``.

    The probes are the routers' own (same seed) and go through the shared
    point cache, so this costs at most ``k + 1`` evaluations, at the probe
    points the routers differenced around without reading. A probe failure or
    a non-finite value returns ``None``: that decline has another cause.
    """
    rng = np.random.default_rng(seed)
    try:
        vals = np.array([float(fun(p)) for p in _probe_points(x0, lb, ub, rng)])
    except Exception:  # noqa: BLE001 — not this cause
        return None
    if not np.all(np.isfinite(vals)):
        return None
    mag = float(np.max(np.abs(vals)))
    spread = float(np.max(vals) - np.min(vals))
    if mag > 0.0 and spread <= _HIDDEN_ULPS * _EPS * mag:
        return mag, spread
    return None


def _flat_along(fun, a, p, tol0):
    """No curvature of ``fun`` along ``a → p`` beyond its rounding.

    ``f(a) + f(p) − 2 f(m)`` with ``m`` the midpoint is ``¼ dᵀPd`` for a
    quadratic and ``0`` for an affine function, whatever the step. ``m`` lies
    on the segment, so it is inside any box both ends are in. Raises
    :class:`_NotConvex` on a non-finite value, as the stencils do.
    """
    d = p - a
    fa, fp, fm = (float(fun(y)) for y in (a, p, a + 0.5 * d))
    if not (np.isfinite(fa) and np.isfinite(fp) and np.isfinite(fm)):
        raise _NotConvex("objective is not finite at a probe")
    s = fa + fp - 2.0 * fm
    allow = 0.25 * tol0 * float(np.sum(np.abs(d)))
    allow += _F_ULPS * _EPS * (abs(fa) + abs(fp) + 2.0 * abs(fm))
    return abs(s) <= allow


def _objective_model(fun, grad, hess, probes):
    """Fit the objective to ``c·x + d`` (LP) or ``½xᵀPx + c·x + d`` (QP).

    Returns ``(P_or_None, c, d)``; raises :class:`_NotConvex` if the gradient
    is not affine-consistent enough to be a quadratic with a *constant*
    Hessian. The quadratic vs. linear vs. nonlinear decision is finalized by
    the held-out validation in :func:`classify_and_extract`.
    """
    anchor = probes[0]
    grads = [grad(p) for p in probes]
    g0 = grads[0]
    gscale = max(1.0, float(np.max(np.abs(g0))))

    # Linear objective ⇔ the gradient is the same at every probe. A gradient
    # finite-differenced from ``fun`` (no ``jac``) carries round-off that grows
    # with ``|f|``, not with the gradient, so a fixed tolerance alone misread
    # an LP as a QP once ``|f|`` was large (an objective offset of 1e7, gh
    # #1169). It is allowed for here, per component, from the values each
    # stencil combined. Curvature hidden inside that allowance changes ``fun``
    # over the probe region by less than ``fun``'s own rounding there, so no
    # fit from values could resolve it; the QP fit it fell to before read the
    # same round-off as its Hessian.
    #
    # That allowance is wide: it divides ``fun``'s rounding by the stencil
    # step, so on its own it would pass curvature that the probe spread can
    # see. A noise-admitted LP must therefore also have no curvature along
    # each probe direction ``d = p − anchor``, read from values alone: for a
    # quadratic ``f(a) + f(p) − 2 f(a + d/2) = ¼ dᵀPd`` exactly, with rounding
    # of a few ulps of ``|f|`` and no division by a small step. The absolute
    # term is the exact-gradient gate's own bound on ``|dᵀPd|``, so in the
    # noise-free limit both tests accept the same objectives. Curvature that
    # survives both changes ``fun`` along the probe region by less than its
    # own rounding there.
    noise = getattr(grad, "noise", None)
    tol0 = 1e-7 * gscale
    if noise is None:
        lin = all(float(np.max(np.abs(gi - g0))) <= tol0 for gi in grads[1:])
    else:
        n0 = noise(anchor)
        lin = all(
            bool(np.all(np.abs(gi - g0) <= tol0 + noise(p) + n0))
            for p, gi in zip(probes[1:], grads[1:])
        ) and all(_flat_along(fun, anchor, p, tol0) for p in probes[1:])
    if lin:
        c = g0
        d = float(fun(anchor)) - float(c @ anchor)
        return None, c, d

    # Otherwise fit a quadratic. With finite differences, require the Hessian
    # to be constant across two probes (a true quadratic's is); with an exact
    # user ``hess`` one evaluation already pins it.
    P = _hessian(grad, anchor, hess)
    if hess is None:
        P2 = _hessian(grad, probes[1], hess)
        pscale = max(1.0, float(np.max(np.abs(P))))
        if float(np.max(np.abs(P - P2))) > 1e-4 * pscale:
            raise _NotConvex("Hessian is not constant — objective is not quadratic")
    # grad(x) = P x + c  ⇒  c = grad(anchor) − P·anchor.
    c = g0 - P @ anchor
    d = float(fun(anchor)) - (0.5 * float(anchor @ P @ anchor) + float(c @ anchor))
    return P, c, d


def _fit_objective(fun, grad, hess, probes, rtol, allow_indefinite: bool = False):
    """Fit + validate + convexity-check the objective, shared by the LP/QP and
    QCQP routers.

    Returns ``(P_or_None, c, d, psd)`` for ``½xᵀPx + cᵀx + d`` (``P is None`` ⇔
    linear, and then ``psd`` is trivially ``True``). Raises :class:`_NotConvex`
    if the objective does not match its fitted linear/quadratic model at the
    held-out probes, or — unless ``allow_indefinite`` — if the quadratic's
    Hessian is indefinite (a nonconvex QP).

    ``allow_indefinite`` is for the one caller that has an engine for a
    nonconvex QP: `pounce-qp`'s active-set method controls the inertia of the
    reduced Hessian (gh #786) and certifies the point it reaches against
    second-order optimality before reporting it (gh #848). It relaxes *only*
    the curvature test — the model-fit validation above it is what proves the
    problem is a QP at all, and no caller may skip that."""
    P, c, d = _objective_model(fun, grad, hess, probes)
    for p in probes[1:]:
        quad = 0.5 * float(p @ P @ p) if P is not None else 0.0
        model = quad + float(c @ p) + d
        fv = float(fun(p))
        if abs(model - fv) > rtol * (1.0 + abs(fv)):
            raise _NotConvex("objective does not match its linear/quadratic model")
    psd = True
    if P is not None:
        eig = np.linalg.eigvalsh(P)
        psd = float(eig.min()) >= -1e-8 * max(1.0, abs(float(eig.max())))
        if not psd and not allow_indefinite:
            raise _NotConvex("indefinite Hessian — nonconvex QP")
    return P, c, d, psd


def _linear_constraints(g_combined, jac_combined, cl, cu, probes, m):
    """Recover ``A x = b`` / ``G x ≤ h`` from the coalesced constraint
    callable, or raise :class:`_NotConvex` if any constraint is nonlinear.

    ``cl``/``cu`` carry the scipy-style two-sided bounds that
    ``_wrap_constraints`` produced (``[0, 0]`` for an equality, ``[0, ∞]``
    for ``g(x) ≥ 0``). The constraint value model is ``g(x) = J x + g0``.
    """
    if m == 0:
        return None, None, None, None

    anchor = probes[0]
    J0 = np.atleast_2d(np.asarray(jac_combined(anchor), dtype=np.float64))
    g_anchor = np.asarray(g_combined(anchor), dtype=np.float64).ravel()
    g0 = g_anchor - J0 @ anchor  # the affine offset

    jscale = max(1.0, float(np.max(np.abs(J0))))
    for p in probes[1:]:
        gp = np.asarray(g_combined(p), dtype=np.float64).ravel()
        model = J0 @ p + g0
        if float(np.max(np.abs(gp - model))) > 1e-6 * (1.0 + float(np.max(np.abs(gp)))):
            raise _NotConvex("a constraint is nonlinear")
        Jp = np.atleast_2d(np.asarray(jac_combined(p), dtype=np.float64))
        if float(np.max(np.abs(Jp - J0))) > 1e-6 * jscale:
            raise _NotConvex("a constraint Jacobian is not constant")

    A_rows, b_vals, G_rows, h_vals = [], [], [], []
    for i in range(m):
        Ji, off = J0[i], g0[i]
        lo, hi = cl[i], cu[i]
        if np.isfinite(lo) and np.isfinite(hi) and lo == hi:
            # Equality g = lo  ⇒  J x = lo − off.
            A_rows.append(Ji)
            b_vals.append(lo - off)
            continue
        if np.isfinite(hi):
            # g ≤ hi  ⇒  J x ≤ hi − off.
            G_rows.append(Ji)
            h_vals.append(hi - off)
        if np.isfinite(lo):
            # g ≥ lo  ⇒  −J x ≤ off − lo.
            G_rows.append(-Ji)
            h_vals.append(off - lo)

    A = np.array(A_rows, dtype=np.float64) if A_rows else None
    b = np.array(b_vals, dtype=np.float64) if b_vals else None
    G = np.array(G_rows, dtype=np.float64) if G_rows else None
    h = np.array(h_vals, dtype=np.float64) if h_vals else None
    return A, b, G, h


def _clean_bounds(lb, ub):
    """Drop an all-infinite bound vector to ``None`` (no box)."""
    if lb is not None and np.all(np.isinf(lb)):
        lb = None
    if ub is not None and np.all(np.isinf(ub)):
        ub = None
    return lb, ub


def classify_and_extract(
    *,
    fun,
    jac,
    hess,
    lb,
    ub,
    m,
    g_combined,
    jac_combined,
    cl,
    cu,
    x0,
    rtol: float = 1e-5,
    seed: int = 0,
    allow_indefinite: bool = False,
    fd_rows=None,
) -> QpExtract | None:
    """Detect an LP/QP behind the callable problem and extract its data.

    Returns a :class:`QpExtract` if the objective is linear or convex-quadratic
    *and* every constraint is linear (validated at held-out probe points),
    otherwise ``None`` (route to the NLP solver). Any evaluation error during
    probing — a domain error, a NaN, a shape surprise — also yields ``None``:
    we never let a probe failure turn into a wrong solver choice.

    ``allow_indefinite`` additionally admits a quadratic objective whose
    Hessian is indefinite, tagging it ``kind="nonconvex_qp"``. Only a caller
    holding an engine for one may ask — today that is
    ``solver_selection="qp-active-set"`` (gh #786). Everything else about the
    detection is unchanged, the linear-constraint requirement included: the
    active-set engine controls the *objective's* curvature, not a row's.
    """
    rng = np.random.default_rng(seed)
    grad = _grad_fn(fun, jac, lb, ub)
    jac_combined = _constraint_jac(g_combined, jac_combined, fd_rows, lb, ub)
    try:
        probes = _probe_points(x0, lb, ub, rng)
        P, c, d, psd = _fit_objective(
            fun, grad, hess, probes, rtol, allow_indefinite=allow_indefinite
        )
        A, b, G, h = _linear_constraints(g_combined, jac_combined, cl, cu, probes, m)
    except _NotConvex:
        return None
    except Exception:  # noqa: BLE001 — any probe failure means "not routable"
        # Probing blew up (domain error, NaN, bad shape) — stay on the NLP path.
        return None

    lb_c, ub_c = _clean_bounds(lb, ub)
    if P is None:
        kind = "lp"
    else:
        kind = "convex_qp" if psd else "nonconvex_qp"
    return QpExtract(
        kind=kind,
        P=P,
        c=np.asarray(c, dtype=np.float64).ravel(),
        obj_const=float(d),
        A=A,
        b=b,
        G=G,
        h=h,
        lb=lb_c,
        ub=ub_c,
    )


# ---------------------------------------------------------------------------
# Convex QCQP → SOCP detection
# ---------------------------------------------------------------------------


def _all_constraint_hessians(jac_combined, x, m, n):
    """Central-difference Hessian of every constraint row from the combined
    Jacobian, in one pass of ``2n`` Jacobian evaluations.

    Returns a list of ``m`` symmetric ``n×n`` arrays; ``Hs[i]`` is the Hessian
    of constraint row ``i``. (The constraint functions come through the scipy
    facade as opaque callables with no user-supplied Hessian, so this is the
    only way to read a quadratic constraint's curvature.)

    When ``jac_combined`` comes from :func:`_constraint_jac`, its
    finite-differenced rows are differenced again with :func:`_box_diff`'s
    stencil (exact on the affine Jacobian of a quadratic row, gh #1169), and
    rows with an analytic Jacobian keep the step and stencil they always had.
    """
    box = getattr(jac_combined, "fd_box", None)
    if box is None:
        exact, fd_idx = jac_combined, None
    else:
        exact, fd_idx = jac_combined.exact, jac_combined.fd_idx
    Hs = [np.empty((n, n)) for _ in range(m)]
    if exact is not None:
        for j in range(n):
            step = _H_HESS * max(1.0, abs(x[j]))
            xp = x.copy()
            xm = x.copy()
            xp[j] += step
            xm[j] -= step
            Jp = np.atleast_2d(np.asarray(exact(xp), dtype=np.float64))
            Jm = np.atleast_2d(np.asarray(exact(xm), dtype=np.float64))
            col = (Jp - Jm) / (2.0 * step)  # shape (m, n): column j of each Hessian
            for i in range(m):
                Hs[i][:, j] = col[i]
    if fd_idx is not None:

        def J_fd(y):
            return np.atleast_2d(np.asarray(jac_combined(y), dtype=np.float64))[fd_idx]

        for j in range(n):
            col = _box_diff(
                J_fd, x, j, _H_STRUCT, _H_HESS, box[0], box[1], quadratic=False
            )
            for k, i in enumerate(fd_idx):
                Hs[i][:, j] = col[k]
    return [0.5 * (H + H.T) for H in Hs]


def _psd_outer_factor(H, n):
    """Pivoted (rank-revealing) Cholesky of a PSD matrix ``H``: returns the
    factor rows ``f_k`` with ``Σ_k f_k f_kᵀ = H`` (i.e. ``FᵀF = H``).

    A Python port of ``qp_extract::psd_outer_factor`` — the row count is the
    numerical rank, so a rank-deficient ``Q`` yields the minimal cone, and
    complete diagonal pivoting stays stable on the indefinite-looking-but-PSD
    matrices finite precision produces.
    """
    a = np.array(H, dtype=np.float64).reshape(n, n).copy()
    rows = []
    max_diag = max((float(a[i, i]) for i in range(n)), default=0.0)
    tol = 1e-12 * max(max_diag, 1.0)
    for _ in range(n):
        diag = np.diag(a)
        p = int(np.argmax(diag))
        best = float(diag[p])
        if best <= tol:
            break
        d = np.sqrt(best)
        f = a[:, p] / d
        a -= np.outer(f, f)
        rows.append(f.copy())
    return rows


def classify_and_extract_socp(
    *,
    fun,
    jac,
    hess,
    lb,
    ub,
    m,
    g_combined,
    jac_combined,
    cl,
    cu,
    x0,
    rtol: float = 1e-5,
    seed: int = 0,
    fd_rows=None,
) -> SocpExtract | None:
    """Detect a convex QCQP behind the callable problem and reformulate it to a
    standard-form SOCP.

    Accepts a linear or convex-quadratic objective, linear equalities, and
    inequality constraints that are each either linear or **convex-quadratic**
    (a one-sided quadratic row qualifies when its feasible set is convex:
    ``g ≥ lo`` — a scipy ``ineq`` — with ``g`` concave, or ``g ≤ hi`` with
    ``g`` convex; a two-sided quadratic row is rejected, gh #1174). Each
    convex-quadratic inequality ``½xᵀHx + aᵀx + b ≤ 0`` (``H = −∇²g ⪰ 0``) becomes one second-order cone via
    the same ``s=−(aᵀx+b)`` → ``(s+1, s−1, √2·Fx) ∈ SOC`` reformulation the CLI
    uses (``FᵀF = H``).

    Returns a :class:`SocpExtract`, or ``None`` to fall back to the NLP solver.
    Conservative throughout: a quadratic *equality*, an indefinite (nonconvex)
    constraint Hessian, a non-constant Hessian (genuinely nonlinear), any model
    that fails held-out validation, or any probe that raises all yield ``None``.
    A purely linear/convex-QP problem (no quadratic constraint) also returns
    ``None`` — that is the LP/QP router's job, not this one.
    """
    n = x0.size
    rng = np.random.default_rng(seed)
    grad = _grad_fn(fun, jac, lb, ub)
    jac_combined = _constraint_jac(g_combined, jac_combined, fd_rows, lb, ub)
    try:
        probes = _probe_points(x0, lb, ub, rng)
        P, c, d, _psd = _fit_objective(fun, grad, hess, probes, rtol)
        anchor = probes[0]

        # Per-constraint models. Each row is linear (Q = 0) or convex-quadratic.
        Hs = _all_constraint_hessians(jac_combined, anchor, m, n) if m else []
        Hs2 = _all_constraint_hessians(jac_combined, probes[1], m, n) if m else []
        J0 = (
            np.atleast_2d(np.asarray(jac_combined(anchor), dtype=np.float64))
            if m
            else np.zeros((0, n))
        )
        g0 = (
            np.asarray(g_combined(anchor), dtype=np.float64).ravel()
            if m
            else np.zeros(0)
        )

        A_rows, b_vals = [], []
        lin_G, lin_h = [], []
        # Each SOC block: (f_rows, a_vec, b_eff) for ½xᵀHx + a·x + b_eff ≤ 0.
        soc_blocks = []
        has_quadratic = False

        for i in range(m):
            Qi = Hs[i]
            Ji = J0[i]
            qscale = float(np.max(np.abs(Qi))) if Qi.size else 0.0
            jscale = max(1.0, float(np.max(np.abs(Ji))) if Ji.size else 0.0)
            is_quad = qscale > 1e-6 * jscale

            lo, hi = float(cl[i]), float(cu[i])
            eq = np.isfinite(lo) and np.isfinite(hi) and lo == hi

            if is_quad:
                if eq:
                    raise _NotConvex("a quadratic equality is nonconvex")
                # The Hessian of a true quadratic is constant across probes;
                # a varying one means a genuinely nonlinear (cubic+) constraint.
                if float(np.max(np.abs(Qi - Hs2[i]))) > 1e-4 * max(1.0, qscale):
                    raise _NotConvex("a constraint Hessian is not constant")
                # Write g(x) = ½xᵀQx + a_g·x + b_g.
                a_g = Ji - Qi @ anchor
                b_g = g0[i] - (0.5 * float(anchor @ Qi @ anchor) + float(a_g @ anchor))
                # Validate the fitted quadratic against the true g at held-out
                # probes — the gate against a higher-degree constraint slipping
                # through as a wrong-but-plausible quadratic.
                for p in probes[1:]:
                    gp = float(np.asarray(g_combined(p), dtype=np.float64).ravel()[i])
                    model = 0.5 * float(p @ Qi @ p) + float(a_g @ p) + b_g
                    if abs(gp - model) > rtol * (1.0 + abs(gp)):
                        raise _NotConvex(
                            "a constraint does not match its quadratic model"
                        )
                # Which side of the row binds decides the sign (gh #1174):
                #   g ≥ lo  ⇔  −(g − lo) ≤ 0, convex iff −Q ⪰ 0;
                #   g ≤ hi  ⇔    g − hi  ≤ 0, convex iff  Q ⪰ 0 — scipy's
                #   natural ``NonlinearConstraint(q, -inf, ub)`` spelling.
                # Both finite with Q ≠ 0 is a band between two quadric level
                # sets whose far side is nonconvex (an annulus) unless Q is
                # degenerate enough to make it vacuous. Reject it
                # conservatively; never read only one side.
                lo_fin, hi_fin = bool(np.isfinite(lo)), bool(np.isfinite(hi))
                if lo_fin and hi_fin:
                    raise _NotConvex(
                        "a two-sided quadratic constraint has a nonconvex feasible set"
                    )
                if not lo_fin and not hi_fin:
                    continue  # −∞ ≤ g ≤ ∞ constrains nothing
                has_quadratic = True
                if lo_fin:
                    H, a_vec, b_eff = -Qi, -a_g, lo - b_g
                else:
                    H, a_vec, b_eff = Qi, a_g, b_g - hi
                eigh = np.linalg.eigvalsh(H)
                if float(eigh.min()) < -1e-8 * max(1.0, abs(float(eigh.max()))):
                    raise _NotConvex(
                        "a constraint is quadratic but its feasible set is nonconvex"
                    )
                f_rows = _psd_outer_factor(H, n)
                # ½xᵀHx + a_vec·x + b_eff ≤ 0
                soc_blocks.append((f_rows, a_vec, b_eff))
                continue

            # Linear row. Validate the affine model, then place it.
            off = g0[i] - Ji @ anchor
            for p in probes[1:]:
                gp = float(np.asarray(g_combined(p), dtype=np.float64).ravel()[i])
                model = float(Ji @ p) + float(off)
                if abs(gp - model) > 1e-6 * (1.0 + abs(gp)):
                    raise _NotConvex(
                        "a constraint is neither linear nor convex-quadratic"
                    )
            if eq:
                A_rows.append(Ji)
                b_vals.append(lo - off)
            else:
                if np.isfinite(hi):
                    lin_G.append(Ji)
                    lin_h.append(hi - off)
                if np.isfinite(lo):
                    lin_G.append(-Ji)
                    lin_h.append(off - lo)

        # No quadratic constraint ⇒ this is an LP/QP, not a QCQP; defer to the
        # LP/QP router so the cheaper, exact path handles it.
        if not has_quadratic:
            raise _NotConvex("no quadratic constraint — not a QCQP")

        # Finite variable bounds → nonnegative rows (solve_socp has no box).
        lb_c, ub_c = _clean_bounds(lb, ub)
        if ub_c is not None:
            for i in range(n):
                if np.isfinite(ub_c[i]):
                    row = np.zeros(n)
                    row[i] = 1.0
                    lin_G.append(row)
                    lin_h.append(float(ub_c[i]))
        if lb_c is not None:
            for i in range(n):
                if np.isfinite(lb_c[i]):
                    row = np.zeros(n)
                    row[i] = -1.0
                    lin_G.append(row)
                    lin_h.append(-float(lb_c[i]))

        # Assemble G/h/cones: the nonnegative block first, then one SOC per
        # quadratic — the cone list must cover G's rows in this order.
        cones = []
        G_rows = list(lin_G)
        h_vals = list(lin_h)
        if len(lin_h) > 0:
            cones.append(("nonneg", len(lin_h)))
        sqrt2 = np.sqrt(2.0)
        for f_rows, a_vec, b_eff in soc_blocks:
            r = len(f_rows)
            # Centre the cone (gh #1041): complete the square so the slack is
            # √2·(Fx + w) rather than √2·Fx. Uncentred, a ball far from the
            # origin carries ‖Fx‖² and −2(a·x + b_eff) as two ~1e6 numbers
            # whose difference is the constraint, and the conic IPM stalls at
            # an infeasible point. Same as the CLI's `centre_soc`.
            a_vec = np.asarray(a_vec, dtype=np.float64)
            w = np.zeros(r)
            if r:
                F = np.asarray(f_rows, dtype=np.float64)
                w = np.linalg.lstsq(F.T, a_vec, rcond=None)[0]
                ftw = F.T @ w
                a_vec = a_vec - ftw
                # Drop roundoff left by an in-range `a`.
                roundoff = (
                    16.0
                    * np.finfo(float).eps
                    * np.maximum(np.abs(a_vec + ftw), np.abs(ftw))
                )
                a_vec[np.abs(a_vec) <= roundoff] = 0.0
                b_eff = b_eff - 0.5 * float(w @ w)
            # Balance the rotated cone (gh #1056): s0 = s/κ + κ, s1 = s/κ − κ
            # with s = −b_eff − a·x. s0² − s1² = 4s, so membership is unchanged,
            # but neither factor carries all of |b_eff|. With κ = 1, `1e20 ± 1`
            # both round to 1e20 and the declared cone is empty. Same as the
            # CLI's `rotated_cone_balance`; κ = 1 for |b_eff| ≤ 1.
            kappa = _rotated_cone_balance(b_eff)
            G_rows.append(a_vec / kappa)
            h_vals.append(-b_eff / kappa + kappa)
            G_rows.append(a_vec / kappa)
            h_vals.append(-b_eff / kappa - kappa)
            # s_{2+k} = √2·(Fx + w)_k  ⇒  G row = −√2·F_k, h = √2·w_k.
            for f, wk in zip(f_rows, w):
                G_rows.append(-sqrt2 * np.asarray(f, dtype=np.float64))
                h_vals.append(sqrt2 * float(wk))
            cones.append(("soc", r + 2))

        A = np.array(A_rows, dtype=np.float64) if A_rows else None
        b = np.array(b_vals, dtype=np.float64) if b_vals else None
        G = np.array(G_rows, dtype=np.float64) if G_rows else None
        h = np.array(h_vals, dtype=np.float64) if h_vals else None
    except _NotConvex:
        return None
    except Exception:  # noqa: BLE001 — any probe failure means "not routable"
        return None

    return SocpExtract(
        kind="convex_qcqp",
        P=P,
        c=np.asarray(c, dtype=np.float64).ravel(),
        obj_const=float(d),
        A=A,
        b=b,
        G=G,
        h=h,
        cones=cones,
    )
