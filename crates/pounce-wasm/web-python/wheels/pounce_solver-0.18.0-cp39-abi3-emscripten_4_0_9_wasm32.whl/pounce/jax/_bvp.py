"""Differentiable boundary value problem solver (JAX frontend).

``pounce.jax.solve_bvp`` discretises a BVP with the same fixed-mesh
Hermite--Simpson collocation as :func:`pounce.bvp.solve_bvp`, but poses the
square collocation root-find ``R(z, theta) = 0`` as a pounce *feasibility*
NLP (``min 0`` s.t. ``R = 0``) routed through :func:`pounce.jax.solve`. The
converged node states ``y`` and unknown parameters ``p`` are therefore
differentiable w.r.t. ``theta`` — any quantity ``fun`` / ``bc`` close over
(a physical coefficient, a boundary value, ...) — via the
implicit-function theorem on the collocation KKT system:

    dz*/dtheta = -(dR/dz)^{-1} (dR/dtheta).

For the square, all-equality feasibility problem the generic pounce.jax
implicit-diff backward collapses to exactly this Newton sensitivity (the
objective Hessian is absent, every constraint row is an active equality,
and there are no variable bounds), so ``jax.grad`` / ``jax.jacobian``
through the returned ``y`` / ``p`` give the right gradients with no
BVP-specific backward code.

``fun`` and ``bc`` take ``theta`` as a trailing argument
(``fun(x, y, p, theta)`` / ``bc(ya, yb, p, theta)``, or without ``p`` when
there are no unknown parameters) and must be JAX-traceable. The mesh,
initial guess, and pounce options are static.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable

import jax
import jax.numpy as jnp
from jax.flatten_util import ravel_pytree

from . import solve as _pounce_solve
from ..bvp import _core
from ..bvp._solve import _make_spline


@dataclass
class JaxBVPSolution:
    """Differentiable BVP solution.

    ``y`` ``(n, m)`` and ``p`` ``(k,)`` are JAX arrays differentiable
    w.r.t. ``theta``; differentiate through them with ``jax.grad`` /
    ``jax.jacrev`` or, on the default ``method="newton"`` path, also
    ``jax.jvp`` / ``jax.jacfwd`` (gh#1229). ``z`` is the flat unknown vector and
    ``yp`` the node derivatives. ``sol`` is a (non-differentiable) cubic
    Hermite interpolant over concrete values for plotting / evaluation.
    """

    y: jnp.ndarray
    p: Any
    z: jnp.ndarray
    yp: jnp.ndarray
    sol: Callable


def _make_newton_vjp(fun, bc, n, m, k, uses_p, tol, theta_ndim):
    """First-order-differentiable feral-Newton solve (``method="newton"``).

    Returns ``solve_fn(theta, x, z0) -> z*``. Forward: damped Newton on
    ``R(z, theta, x) = 0`` factoring the ``N x N`` collocation Jacobian with
    FERAL's sparse LU (host ``pure_callback``). Derivatives: an
    implicit-function-theorem ``custom_jvp`` (gh#1229, see
    :mod:`pounce.jax._ift`). A tangent is ``ż = -R_z⁻¹ (∂R/∂(theta, x) ·
    ṫheta)``, solved with the sparse LU of ``R_z`` at ``z*``; reverse mode
    is JAX's transpose of that rule, which back-solves ``R_zᵀ u = v`` with
    the same factor. Both directions stay on the ``N`` system — no ``2N``
    saddle — so it is the fast path, and ``jvp`` / ``jacfwd`` work as well
    as ``grad`` / ``jacrev``.

    The mesh ``x`` and the initial guess ``z0`` are callback *operands*,
    not values read at trace time, so either may be a tracer — built
    inside ``jax.jit``, passed in as a jitted argument, or vmapped. ``z*``
    does not depend on ``z0`` (a root is a root), so its cotangent is an
    exact zero.
    """
    import numpy as np
    from ..bvp._jac import CollocationJacobian
    from ..bvp._newton import newton_solve
    from ..bvp._solve import ift_solve_lanes
    from ._ift import make_ift_root

    def residual_jax(z, theta, x):
        nfun, nbc = _core._make_normalized(fun, bc, theta=theta, uses_p=uses_p)
        Y, pp = _core.unpack_z(z, n, m)
        return _core.collocation_residual(nfun, nbc, x, Y, pp, jnp.concatenate)

    def _np_normalized(theta_np):
        nfun_j, nbc_j = _core._make_normalized(fun, bc, theta=theta_np, uses_p=uses_p)
        nfun = lambda xx, YY, pp: np.asarray(nfun_j(xx, YY, pp), dtype=np.float64)
        nbc = lambda ya, yb, pp: np.asarray(nbc_j(ya, yb, pp), dtype=np.float64)
        return nfun, nbc

    def _host_newton(theta_np, x_np, z0_np):
        x_np = np.asarray(x_np, dtype=np.float64)
        z0_np = np.asarray(z0_np, dtype=np.float64)
        nfun, nbc = _np_normalized(theta_np)

        def residual_fn(z):
            return _core.residual_of_z(z, nfun, nbc, x_np, n, m, k, np.concatenate)

        jac = CollocationJacobian(nfun, nbc, x_np, n, m, k)
        z_star, _it, _ok, _rn = newton_solve(
            residual_fn, jac, z0_np, n, m, k, tol=float(tol),
        )
        return np.asarray(z_star, dtype=np.float64)

    def _host_lin(z_star_np, theta_np, x_np, v_np, transpose):
        # Under vmap_method="broadcast_all" every operand gains the same
        # leading batch axes. Lanes may share one primal (jax.jacobian) or
        # carry distinct ones (an outer vmap over theta or the mesh), so the
        # helper groups them by primal rather than collapsing to lane 0
        # (gh#1049).
        return ift_solve_lanes(
            _np_normalized, x_np, n, m, k, z_star_np, theta_np, v_np,
            theta_ndim, transpose=transpose,
        )

    N = n * m + k

    def _forward(theta, x, z0):
        return jax.pure_callback(
            _host_newton, jax.ShapeDtypeStruct((N,), jnp.float64), theta, x, z0,
            vmap_method="sequential",
        )

    def _lin_solve(z_star, args, b, transpose):
        theta, x, _z0 = args
        # jacfwd / jacrev vmap the rule over basis vectors, which vmaps this
        # callback; broadcast_all hands the whole batch to one invocation, so
        # R_z is factored once per distinct primal and the solves run
        # multi-RHS.
        return jax.pure_callback(
            lambda zz, th, xx, bb: _host_lin(zz, th, xx, bb, transpose),
            jax.ShapeDtypeStruct((N,), jnp.float64),
            z_star, theta, x, b, vmap_method="broadcast_all",
        )

    # residual_jax ignores z0, so z0's tangent is an exact zero.
    return make_ift_root(
        _forward, lambda z, th, xx, _z0: residual_jax(z, th, xx), _lin_solve,
    )


def solve_bvp(
    fun, bc, x, y, p=None, theta=None, *,
    tol=1e-8, options=None, method="newton", second_order=False,
):
    """Solve a BVP differentiably w.r.t. ``theta`` with JAX + pounce.

    Parameters
    ----------
    fun, bc : callable
        ``fun(x, y, p, theta) -> (n, m)`` and
        ``bc(ya, yb, p, theta) -> (n + k,)`` (drop ``p`` if there are no
        unknown parameters). JAX-traceable.
    x : array (m,)
        Fixed mesh (not adapted). May be traced — built under ``jax.jit``,
        a jitted argument, or vmapped — and is differentiable: the
        gradient is the implicit-function derivative of the collocation
        solution w.r.t. the node positions.
    y : array (n, m)
        Initial guess for the node states. May be traced; its gradient is
        an exact zero (the root does not depend on where Newton starts).
    p : array (k,) or None
        Initial guess for unknown parameters, or ``None``.
    theta : array-like
        The differentiation parameter threaded into ``fun`` / ``bc``. On the
        default ``method="newton"`` path this must be an array or scalar (it
        is passed as a single callback argument); structured pytree ``theta``
        is only supported on ``method="ipm"``.
    tol : float
        pounce convergence tolerance.
    options : dict or None
        Extra pounce options.
    second_order : bool
        When ``False`` (default) the solve routes through
        :func:`pounce.jax.solve`'s first-order ``custom_vjp`` — efficient
        (the backward reuses the forward's converged duals, no re-solve),
        but ``jax.grad`` only (``jax.grad(jax.grad(...))`` / ``jax.hessian``
        raise, because that path's forward crosses a ``pure_callback`` with
        no JVP rule). When ``True`` the solve is wrapped in a ``custom_jvp``
        whose tangent rule re-applies the implicit-function theorem to the
        collocation root-find ``dz/dtheta = -(dR/dz)^{-1} (dR/dtheta)`` and
        recomputes the solution through the *same* custom-ruled primitive,
        so JAX recurses for arbitrary differentiation order (``jax.hessian``
        works). The cost is one extra forward solve per differentiation
        level (the rule re-solves to recover ``z*``); the opaque forward is
        only ever evaluated for primal values, never differentiated. Use
        this for second derivatives / Newton-type outer loops; leave it off
        for plain gradient-based training.

    Returns
    -------
    JaxBVPSolution
    """
    if theta is None:
        raise ValueError(
            "pounce.jax.solve_bvp requires `theta` (the differentiation "
            "parameter). For a plain non-differentiable solve use "
            "pounce.bvp.solve_bvp."
        )

    x = jnp.asarray(x, dtype=jnp.float64)
    y = jnp.asarray(y, dtype=jnp.float64)
    n, m = y.shape
    uses_p = p is not None
    p0 = jnp.asarray(p, dtype=jnp.float64).ravel() if uses_p else jnp.zeros(0)
    k = int(p0.shape[0])
    N = _core.num_unknowns(n, m, k)

    # The ipm path hands the solve one flat parameter vector carrying both
    # ``theta`` (any pytree) and the mesh ``x``. Closing ``g`` over ``x``
    # instead leaks it out of the trace when the mesh is built under
    # ``jax.jit`` (the host evaluates ``g``), and ``pounce.jax.solve``
    # differentiates w.r.t. an array ``p`` only — so flattening is what
    # makes a structured ``theta`` work and the mesh differentiable.
    q, _unravel_q = ravel_pytree((theta, x))

    def f(z, q_):
        # Pure feasibility: zero objective (kept dependent on z so the
        # trace has the right shape; grad is identically zero).
        return 0.0 * jnp.sum(z)

    def g(z, q_):
        th, xx = _unravel_q(q_)
        nfun, nbc = _core._make_normalized(fun, bc, theta=th, uses_p=uses_p)
        Y, pp = _core.unpack_z(z, n, m)
        return _core.collocation_residual(nfun, nbc, xx, Y, pp, jnp.concatenate)

    z0 = _core.pack_z(y, p0, jnp.concatenate)
    cl = jnp.zeros(N, dtype=jnp.float64)
    cu = jnp.zeros(N, dtype=jnp.float64)

    opts = {"tol": float(tol), "print_level": 0}
    if options:
        opts.update(options)

    if method == "newton":
        if second_order:
            raise ValueError(
                "second_order=True is only supported with method='ipm' "
                "(the Newton path is already an implicit-function "
                "custom_jvp; it needs no opt-in for jvp / jacfwd)."
            )
        solve_root = _make_newton_vjp(
            fun, bc, n, m, k, uses_p, tol, int(jnp.ndim(theta))
        )
        z_star = solve_root(theta, x, z0)
    elif method == "ipm":
        if second_order:
            solve_root = _make_root_solver_jvp(f, g, z0, N, cl, cu, opts)
            z_star = solve_root(q)
        else:
            z_star = _pounce_solve(
                q, f=f, g=g, x0=z0, n=N, m=N, cl=cl, cu=cu, options=opts,
            )
    else:
        raise ValueError(f"unknown method {method!r}; use 'newton' or 'ipm'.")

    Y_star, p_star = _core.unpack_z(z_star, n, m)
    nfun, _ = _core._make_normalized(fun, bc, theta=theta, uses_p=uses_p)
    yp = nfun(x, Y_star, p_star)

    sol = _make_spline(x, Y_star, yp)

    return JaxBVPSolution(
        y=Y_star,
        p=(p_star if uses_p else None),
        z=z_star,
        yp=yp,
        sol=sol,
    )


def _make_root_solver_jvp(f, g, z0, N, cl, cu, opts):
    """Build a ``custom_jvp`` collocation root-solver, differentiable to
    arbitrary order w.r.t. ``theta``.

    The collocation system is the **square** root-find ``R(z, theta) = 0``
    (``g`` is the residual), so the implicit-function theorem gives the
    tangent ``z_dot = -(dR/dz)^{-1} (dR/dtheta . theta_dot)`` directly — no
    active-set / bound bookkeeping (there are none here). Crucially the
    rule recovers ``z*`` by calling ``solve_root`` again, i.e. through the
    *same* ``custom_jvp`` primitive, so differentiating the rule re-enters
    the rule and JAX composes derivatives to any order. The forward
    ``pure_callback`` (inside :func:`pounce.jax.solve`) is only evaluated
    for primal values; it is never asked for a tangent, which is why this
    sidesteps the "pure callbacks do not support JVP" limitation that
    blocks second-order through the plain :func:`pounce.jax.solve` path.
    """

    @jax.custom_jvp
    def solve_root(theta):
        return _pounce_solve(
            theta, f=f, g=g, x0=z0, n=N, m=N, cl=cl, cu=cu, options=opts,
        )

    @solve_root.defjvp
    def solve_root_jvp(primals, tangents):
        (theta,), (theta_dot,) = primals, tangents
        z = solve_root(theta)
        # R_z (N x N) and the directional derivative R_theta . theta_dot.
        # This forms R_z densely (jnp.linalg.solve) rather than reusing the
        # sparse FERAL LU on purpose: keeping the rule in pure JAX is what
        # lets JAX recurse for arbitrary order (jax.hessian). A FERAL
        # pure_callback has no JVP rule and would break second-order, so the
        # dense O(N^3) solve is the deliberate price of higher-order autodiff
        # on this (opt-in, second_order) path.
        Rz = jax.jacfwd(lambda zz: g(zz, theta))(z)
        _, R_theta_dot = jax.jvp(lambda th: g(z, th), (theta,), (theta_dot,))
        z_dot = -jnp.linalg.solve(Rz, R_theta_dot)
        return z, z_dot

    return solve_root
